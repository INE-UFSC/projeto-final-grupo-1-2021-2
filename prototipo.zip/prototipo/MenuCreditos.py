import pygame, sys
from pygame.locals import *
import Menu

class MenuTutorial(Menu):
    def __init__(self, game):
        Menu.__init__(self, game)

    def display_menu(self):
        pass
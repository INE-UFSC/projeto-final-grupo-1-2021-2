Nesse diretório, o grupo irá trabalhar em cima do primeiro protótipo do jogo.

Objetivo do jogo: coletar os ITENS e levar até o PONTO DE ENTREGA, evitando os obstáculos do mapa e INIMIGOS, antes que o tempo acabe. Caso o JOGADOR colida com um INIMIGO enquanto carrega um ITEM, o mesmo é "derrubado" e volta para a posição original.

Legenda: JOGADOR - azul;
         ITEM - verde claro;
         PONTO DE ENTREGA - verde escuro;
         INIMIGOS - vermelho/laranja;

Controles: W - mover para cima;
           A - mover para a esquerda;
           S - mover para baixo;
           D - mover para a direita;
           ESPAÇO - pegar/entregar item;


A ideia do protótipo não é que ele seja uma versão demo do jogo completo, mas sim que o principal mecanismo do jogo esteja implementado com certo grau de sucesso. Exemplo: em um jogo do tipo plataforma 2D, basta mostrar um retângulo colidindo com objetos e saltando/destruindo com alguma comando do usuário. A interface gráfica (com sprites) é opcional nessa etapa.
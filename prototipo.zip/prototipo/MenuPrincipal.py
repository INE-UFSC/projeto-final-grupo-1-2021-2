
  
import pygame, sys
from pygame.locals import *
import Menu

class MenuPrincipal(Menu):
    def __init__(self, controladorJogo):
        Menu.__init__(self, controladorJogo)
        pass

    def display_menu(self): 
        pass
 
    def move_cursor(self): 
        pass

    def checa_entrada(self):
        pass

from ControladorJogo import ControladorJogo

jogo = ControladorJogo()
jogo.executar()
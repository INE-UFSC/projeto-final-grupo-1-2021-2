import pygame, sys
from pygame.locals import *
import Menu

class OptionsMenu(Menu):
    def __init__(self, game):
        Menu.__init__(self, game)
           
    def display_menu(self):
        pass

    def checa_entrada(self):
        pass
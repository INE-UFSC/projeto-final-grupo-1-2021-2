import pygame, sys
from pygame.locals import *

class Menu:
    def __init__(self, controladorJogo):
        self.controladorJogo = controladorJogo
            